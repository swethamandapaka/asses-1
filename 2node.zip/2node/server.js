const expree = require('express');
const bodyParser = require('body-parser');
const express = require('express');
const app = express();
const port = 3000;
app.set('view engine','ejs');
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static('public'));
let userList = [];
app.get('/',(req,res)=>{
    res.render('index',{userList})
});
app.get('/user/add',(req,res)=>{
    res.render('add-user')
});
app.post('/user/add',(req,res)=>{
   const {name,email,age,city,profession}=req.body;
   const newUser ={name,email,age,city,profession};
   userList.push(newUser);
   res.redirect('/');
});
app.listen(port,()=>{
    console.log('server is running')
})